---
name: Feature approval request
about: Request approval for the implementation of a feature or modification of an existing one
title: ''
labels: feature
assignees: ''

---

**Description**  
Describe what feature you will implement/modify

**Affected components**  
What components of the application will be affected by this?

**Additional comments**  
Any other information that might be helpful but does not fit in the above categories.
